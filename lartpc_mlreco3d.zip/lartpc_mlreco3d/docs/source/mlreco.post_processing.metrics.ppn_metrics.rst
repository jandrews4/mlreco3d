mlreco.post\_processing.metrics.ppn\_metrics module
===================================================

.. automodule:: mlreco.post_processing.metrics.ppn_metrics
   :members:
   :undoc-members:
   :show-inheritance:
