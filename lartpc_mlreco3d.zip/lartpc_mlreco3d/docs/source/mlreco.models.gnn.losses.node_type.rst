mlreco.models.layers.gnn.losses.node\_type module
==========================================

.. automodule:: mlreco.models.layers.gnn.losses.node_type
   :members:
   :undoc-members:
   :show-inheritance:
