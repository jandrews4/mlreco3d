mlreco.post\_processing.analysis.michel\_reconstruction\_noghost module
=======================================================================

.. automodule:: mlreco.post_processing.analysis.michel_reconstruction_noghost
   :members:
   :undoc-members:
   :show-inheritance:
