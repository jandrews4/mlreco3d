mlreco.utils.data\_parallel module
==================================

.. automodule:: mlreco.utils.data_parallel
   :members:
   :undoc-members:
   :show-inheritance:
