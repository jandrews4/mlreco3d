mlreco.models.cluster\_cnn.embeddings module
============================================

.. automodule:: mlreco.models.scn.cluster_cnn.embeddings
   :members:
   :undoc-members:
   :show-inheritance:
