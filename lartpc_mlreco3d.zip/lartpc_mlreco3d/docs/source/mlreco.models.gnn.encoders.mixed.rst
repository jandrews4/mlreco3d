mlreco.models.layers.gnn.encoders.mixed module
=======================================

.. automodule:: mlreco.models.layers.gnn.encoders.mixed
   :members:
   :undoc-members:
   :show-inheritance:
