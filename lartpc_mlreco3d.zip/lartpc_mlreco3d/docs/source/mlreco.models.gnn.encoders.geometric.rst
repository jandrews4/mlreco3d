mlreco.models.layers.gnn.encoders.geometric module
===========================================

.. automodule:: mlreco.models.layers.gnn.encoders.geometric
   :members:
   :undoc-members:
   :show-inheritance:
