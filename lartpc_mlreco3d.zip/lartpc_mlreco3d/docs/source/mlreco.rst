mlreco package
==============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   mlreco.iotools
   mlreco.models
   mlreco.post_processing
   mlreco.utils
   mlreco.visualization

Submodules
----------

.. toctree::
   :maxdepth: 4

   mlreco.main_funcs
   mlreco.trainval

Module contents
---------------

.. automodule:: mlreco
   :members:
   :undoc-members:
   :show-inheritance:
