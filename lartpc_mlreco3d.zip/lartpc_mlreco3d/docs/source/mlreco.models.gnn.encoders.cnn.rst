mlreco.models.layers.gnn.encoders.cnn module
=====================================

.. automodule:: mlreco.models.layers.gnn.encoders.cnn
   :members:
   :undoc-members:
   :show-inheritance:
