mlreco.models.layers.gnn.losses.node\_kinematics module
================================================

.. automodule:: mlreco.models.layers.gnn.losses.node_kinematics
   :members:
   :undoc-members:
   :show-inheritance:
