mlreco.post\_processing.analysis.stopping\_muons module
=======================================================

.. automodule:: mlreco.post_processing.analysis.stopping_muons
   :members:
   :undoc-members:
   :show-inheritance:
