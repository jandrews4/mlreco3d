mlreco.models.layers.gnn.message\_passing.agnnconv module
==================================================

.. automodule:: mlreco.models.layers.gnn.message_passing.agnnconv
   :members:
   :undoc-members:
   :show-inheritance:
