mlreco.models.layers.gnn.message\_passing package
==========================================

Submodules
----------

.. toctree::
   :maxdepth: 4

   mlreco.models.layers.gnn.message_passing.agnnconv
   mlreco.models.layers.gnn.message_passing.econv
   mlreco.models.layers.gnn.message_passing.gatconv
   mlreco.models.layers.gnn.message_passing.meta
   mlreco.models.layers.gnn.message_passing.nnconv
   mlreco.models.layers.gnn.message_passing.nnconv_2
   mlreco.models.layers.gnn.message_passing.nnconv_elu
   mlreco.models.layers.gnn.message_passing.nnconv_old

Module contents
---------------

.. automodule:: mlreco.models.layers.gnn.message_passing
   :members:
   :undoc-members:
   :show-inheritance:
