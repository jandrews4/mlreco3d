mlreco.models.layers.gnn.message\_passing.econv module
===============================================

.. automodule:: mlreco.models.layers.gnn.message_passing.econv
   :members:
   :undoc-members:
   :show-inheritance:
