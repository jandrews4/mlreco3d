mlreco.models.layers.gnn.message\_passing.gatconv module
=================================================

.. automodule:: mlreco.models.layers.gnn.message_passing.gatconv
   :members:
   :undoc-members:
   :show-inheritance:
