mlreco.models.particle\_types module
====================================

.. automodule:: mlreco.models.particle_types
   :members:
   :undoc-members:
   :show-inheritance:
