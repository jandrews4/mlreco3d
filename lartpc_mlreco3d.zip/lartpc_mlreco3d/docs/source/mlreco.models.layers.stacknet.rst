mlreco.models.scn.layers.stacknet module
====================================

.. automodule:: mlreco.models.scn.layers.stacknet
   :members:
   :undoc-members:
   :show-inheritance:
