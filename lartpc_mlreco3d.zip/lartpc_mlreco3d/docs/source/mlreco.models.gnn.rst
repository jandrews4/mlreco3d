mlreco.models.layers.gnn package
=========================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   mlreco.models.layers.gnn.encoders
   mlreco.models.layers.gnn.losses
   mlreco.models.layers.gnn.message_passing

Submodules
----------

.. toctree::
   :maxdepth: 4

   mlreco.models.layers.gnn.cluster
   mlreco.models.layers.gnn.factories
   mlreco.models.layers.gnn.normalizations

Module contents
---------------

.. automodule:: mlreco.models.layers.gnn
   :members:
   :undoc-members:
   :show-inheritance:
