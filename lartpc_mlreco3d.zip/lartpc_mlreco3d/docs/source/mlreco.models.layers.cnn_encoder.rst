mlreco.models.layers.common.cnn\_encoder module
========================================

.. automodule:: mlreco.models.scn.layers.cnn_encoder
   :members:
   :undoc-members:
   :show-inheritance:
