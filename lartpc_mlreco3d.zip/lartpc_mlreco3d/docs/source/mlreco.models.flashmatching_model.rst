mlreco.models.flashmatching\_model module
=========================================

.. automodule:: mlreco.models.flashmatching_model
   :members:
   :undoc-members:
   :show-inheritance:
