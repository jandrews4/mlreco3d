mlreco.models.uresnet\_ppn\_chain module
========================================

.. automodule:: mlreco.models.uresnet_ppn_chain
   :members:
   :undoc-members:
   :show-inheritance:
