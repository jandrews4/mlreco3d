mlreco.models.layers.gnn.message\_passing.nnconv module
================================================

.. automodule:: mlreco.models.layers.gnn.message_passing.nnconv
   :members:
   :undoc-members:
   :show-inheritance:
