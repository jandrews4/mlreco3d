mlreco.post\_processing package
===============================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   mlreco.post_processing.analysis
   mlreco.post_processing.metrics
   mlreco.post_processing.store

Submodules
----------

.. toctree::
   :maxdepth: 4

   mlreco.post_processing.decorator

Module contents
---------------

.. automodule:: mlreco.post_processing
   :members:
   :undoc-members:
   :show-inheritance:
