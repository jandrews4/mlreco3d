mlreco.models.flashmatching\_gnn module
=======================================

.. automodule:: mlreco.models.flashmatching_gnn
   :members:
   :undoc-members:
   :show-inheritance:
