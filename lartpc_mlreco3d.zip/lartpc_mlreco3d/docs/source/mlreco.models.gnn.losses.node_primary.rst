mlreco.models.layers.gnn.losses.node\_primary module
=============================================

.. automodule:: mlreco.models.layers.gnn.losses.node_primary
   :members:
   :undoc-members:
   :show-inheritance:
