mlreco.models.layers.gnn.message\_passing.nnconv\_old module
=====================================================

.. automodule:: mlreco.models.layers.gnn.message_passing.nnconv_old
   :members:
   :undoc-members:
   :show-inheritance:
