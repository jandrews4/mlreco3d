mlreco.models.cluster\_cnn.spatial\_embeddings module
=====================================================

.. automodule:: mlreco.models.scn.cluster_cnn.spatial_embeddings
   :members:
   :undoc-members:
   :show-inheritance:
