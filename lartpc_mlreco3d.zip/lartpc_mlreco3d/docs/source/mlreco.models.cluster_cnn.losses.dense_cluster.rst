mlreco.models.cluster\_cnn.losses.dense\_cluster module
=======================================================

.. automodule:: mlreco.models.scn.cluster_cnn.losses.dense_cluster
   :members:
   :undoc-members:
   :show-inheritance:
