mlreco.models.scn.layers.uresnet module
===================================

.. automodule:: mlreco.models.scn.layers.uresnet
   :members:
   :undoc-members:
   :show-inheritance:
