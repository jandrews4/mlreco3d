mlreco.models.layers.gnn.encoders.gnn module
=====================================

.. automodule:: mlreco.models.layers.gnn.encoders.gnn
   :members:
   :undoc-members:
   :show-inheritance:
