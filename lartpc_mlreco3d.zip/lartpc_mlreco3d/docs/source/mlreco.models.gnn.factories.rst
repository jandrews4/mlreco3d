mlreco.models.layers.gnn.factories module
==================================

.. automodule:: mlreco.models.layers.gnn.factories
   :members:
   :undoc-members:
   :show-inheritance:
