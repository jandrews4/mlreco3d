mlreco.models.chain.full\_cnn module
====================================

.. automodule:: mlreco.models.chain.full_cnn
   :members:
   :undoc-members:
   :show-inheritance:
