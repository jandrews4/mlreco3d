mlreco.models.layers.gnn.message\_passing.nnconv\_elu module
=====================================================

.. automodule:: mlreco.models.layers.gnn.message_passing.nnconv_elu
   :members:
   :undoc-members:
   :show-inheritance:
