mlreco.models.layers.gnn.encoders package
==================================

Submodules
----------

.. toctree::
   :maxdepth: 4

   mlreco.models.layers.gnn.encoders.cnn
   mlreco.models.layers.gnn.encoders.geometric
   mlreco.models.layers.gnn.encoders.gnn
   mlreco.models.layers.gnn.encoders.mixed

Module contents
---------------

.. automodule:: mlreco.models.layers.gnn.encoders
   :members:
   :undoc-members:
   :show-inheritance:
