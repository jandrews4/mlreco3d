mlreco.models.layers.gnn.message\_passing.nnconv\_2 module
===================================================

.. automodule:: mlreco.models.layers.gnn.message_passing.nnconv_2
   :members:
   :undoc-members:
   :show-inheritance:
