mlreco.models.layers.gnn.message\_passing.meta module
==============================================

.. automodule:: mlreco.models.layers.gnn.message_passing.meta
   :members:
   :undoc-members:
   :show-inheritance:
