mlreco.models.cluster\_cnn.losses.spatial\_embeddings\_fast module
==================================================================

.. automodule:: mlreco.models.scn.cluster_cnn.losses.spatial_embeddings_fast
   :members:
   :undoc-members:
   :show-inheritance:
