mlreco.models.layers.common.momentum module
====================================

.. automodule:: mlreco.models.layers.common.momentum
   :members:
   :undoc-members:
   :show-inheritance:
