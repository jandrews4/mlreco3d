mlreco.models.layers.gnn.losses package
================================

Submodules
----------

.. toctree::
   :maxdepth: 4

   mlreco.models.layers.gnn.losses.edge_channel
   mlreco.models.layers.gnn.losses.node_grouping
   mlreco.models.layers.gnn.losses.node_kinematics
   mlreco.models.layers.gnn.losses.node_primary
   mlreco.models.layers.gnn.losses.node_type

Module contents
---------------

.. automodule:: mlreco.models.layers.gnn.losses
   :members:
   :undoc-members:
   :show-inheritance:
