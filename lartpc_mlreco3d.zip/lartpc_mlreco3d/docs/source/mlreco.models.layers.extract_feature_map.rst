mlreco.models.layers.common.extract\_feature\_map module
=================================================

.. automodule:: mlreco.models.scn.layers.extract_feature_map
   :members:
   :undoc-members:
   :show-inheritance:
