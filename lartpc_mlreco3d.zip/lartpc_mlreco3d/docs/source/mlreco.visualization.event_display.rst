mlreco.visualization.event\_display module
==========================================

.. automodule:: mlreco.visualization.event_display
   :members:
   :undoc-members:
   :show-inheritance:
