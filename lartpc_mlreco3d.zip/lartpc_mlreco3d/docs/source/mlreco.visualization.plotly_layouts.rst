mlreco.visualization.plotly\_layouts module
===========================================

.. automodule:: mlreco.visualization.plotly_layouts
   :members:
   :undoc-members:
   :show-inheritance:
