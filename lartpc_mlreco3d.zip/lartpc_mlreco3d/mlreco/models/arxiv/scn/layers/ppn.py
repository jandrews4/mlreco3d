from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import torch
from mlreco.models.scn.layers.extract_feature_map import Selection, Multiply, AddLabels, GhostMask
from mlreco.models.layers.common.dbscan import distances
import numpy as np


def define_ppn12(ppn1_size, ppn2_size, spatial_size, num_strides):
    if ppn1_size == -1:
        ppn1_size = spatial_size/2**4
    if ppn2_size == -1:
        ppn2_size = spatial_size/2**2
    # Make sure spatial sizes match
    if ppn1_size < 0 or ppn1_size > spatial_size:
        raise Exception("PPN1 size must be within [0, %d], got %d" % (spatial_size, ppn1_size))
    if ppn2_size < 0 or ppn2_size > spatial_size:
        raise Exception("PPN2 size must be within [0, %d], got %d" % (spatial_size, ppn2_size))
    if spatial_size % ppn1_size != 0:
        raise Exception("PPN1 size must divide original spatial size (got %d and %d)" % (spatial_size, ppn1_size))
    if spatial_size % ppn2_size != 0:
        raise Exception("PPN2 size must divide the original spatial size (got %d and %d)" % (spatial_size, ppn2_size))
    if ppn1_size >= ppn2_size:
        raise Exception("PPN1 size must be greater than PPN2 size (got %d and %d respectively)" % (ppn1_size, ppn2_size))
    ppn2_stride = int(np.log2(spatial_size / ppn2_size))
    ppn1_stride = int(np.log2(spatial_size / ppn1_size))
    if ppn1_stride >= num_strides:
        raise Exception("Depth (number of strides) must be great enough for PPN1 size %d vs spatial size %d" % (ppn1_size, spatial_size))
    return ppn1_stride, ppn2_stride


class PPN(torch.nn.Module):
    """
    Point Prediction Network (PPN)

    PPN is *not* a standalone network. It is an additional layer to go on top of
    a UResNet-style network that provides feature maps on top of which PPN will
    run some convolutions and predict point positions.

    A typical configuration goes under `uresnet_ppn` in `modules` section:

    ..  code-block:: yaml

        uresnet_ppn:
          ppn:
            num_strides: 6
            filters: 16
            num_classes: 5
            data_dim: 3
            downsample_ghost: True
            use_encoding: False
            ppn_num_conv: 1
            weight_ppn: 0.9
            score_threshold: 0.5
            ppn1_size: 24
            ppn2_size: 96
            spatial_size: 768
            model_path: 'your_snapshot.ckpt'
            model_name: 'ppn'

    Configuration
    -------------
    num_strides : int
        Depth of UResNet, also corresponds to how many times we down/upsample.
    filters : int
        Number of filters in the first convolution of UResNet.
        Will increase linearly with depth.
    num_classes : int
        Should be number of classes (+1 if we include ghost points directly)
    data_dim : int
        Dimension 2 or 3
    use_encoding: bool, optional
        Whether to use feature maps from the encoding or decoding path of UResNet.
    downsample_ghost: bool, optional
        Whether to apply the downsampled ghost mask.
    ppn_num_conv: int, optional
        How many convolutions to apply at each level of PPN.
    ppn1_size: int, optional
        Size in px of the coarsest feature map used by PPN1. Should divide the original spatial size.
    ppn2_size: int, optional
        Size in px of the intermediate feature map used by PPN2. Should divide the original spatial size.
    spatial_size: int, optional
        Size in px of the original image.
    """
    def __init__(self, cfg):
        super(PPN, self).__init__()
        import sparseconvnet as scn
        self._model_config = cfg['ppn']

        self._dimension = self._model_config.get('data_dim', 3)
        self._num_strides = self._model_config.get('num_strides', 5)
        m = self._model_config.get('filters', 16)  # Unet number of features
        num_classes = self._model_config.get('num_classes', 5)
        self._downsample_ghost = self._model_config.get('downsample_ghost', False)
        self._use_encoding = self._model_config.get('use_encoding', False)
        self._use_true_ghost_mask = self._model_config.get('use_true_ghost_mask', False)
        self._classify_endpoints = self._model_config.get('classify_endpoints', False)
        self._ppn_num_conv = self._model_config.get('ppn_num_conv', 1)
        self._ppn1_size = self._model_config.get('ppn1_size', -1)
        self._ppn2_size = self._model_config.get('ppn2_size', -1)
        self._spatial_size = self._model_config.get('spatial_size', 512)
        self.ppn1_stride, self.ppn2_stride = define_ppn12(self._ppn1_size, self._ppn2_size, self._spatial_size, self._num_strides)

        kernel_size = 2  # Use input_spatial_size method for other values?
        nPlanes = [i*m for i in range(1, self._num_strides+1)]  # UNet number of features per level
        # nPlanes = [(2**i) * m for i in range(1, num_strides+1)]  # UNet number of features per level
        downsample = [kernel_size, 2]# downsample = [filter size, filter stride]

        # PPN stuff
        #self.half_stride = int((self._num_strides-1)/2.0)
        #self.half_stride2 = int(self._num_strides/2.0)
        self.ppn1_conv = scn.Sequential()
        for i in range(self._ppn_num_conv):
            self.ppn1_conv.add(scn.SubmanifoldConvolution(self._dimension, nPlanes[self.ppn1_stride-self._num_strides], nPlanes[self.ppn1_stride-self._num_strides], 3, False))
        self.ppn1_scores = scn.SubmanifoldConvolution(self._dimension, nPlanes[self.ppn1_stride-self._num_strides], 2, 3, False)

        self.selection1 = Selection()
        self.selection2 = Selection()
        self.unpool1 = scn.Sequential()
        for i in range(self.ppn1_stride-self.ppn2_stride):
            self.unpool1.add(scn.UnPooling(self._dimension, downsample[0], downsample[1]))

        self.unpool2 = scn.Sequential()
        for i in range(self.ppn2_stride):
            self.unpool2.add(scn.UnPooling(self._dimension, downsample[0], downsample[1]))

        #middle_filters = int(m * self.half_stride * (self.half_stride + 1) / 2.0)
        #print(middle_filters, (self.ppn2_stride+1)*m)
        middle_filters = (self.ppn2_stride+1)*m
        self.ppn2_conv = scn.Sequential()
        for i in range(self._ppn_num_conv):
            self.ppn2_conv.add(scn.SubmanifoldConvolution(self._dimension, middle_filters, middle_filters, 3, False))
        self.ppn2_scores = scn.SubmanifoldConvolution(self._dimension, middle_filters, 2, 3, False)
        self.multiply1 = Multiply()
        self.multiply2 = Multiply()

        self.ppn3_conv = scn.Sequential()
        for i in range(self._ppn_num_conv):
            self.ppn3_conv.add(scn.SubmanifoldConvolution(self._dimension, nPlanes[0], nPlanes[0], 3, False))
        self.ppn3_pixel_pred = scn.SubmanifoldConvolution(self._dimension, nPlanes[0], self._dimension, 3, False)
        self.ppn3_scores = scn.SubmanifoldConvolution(self._dimension, nPlanes[0], 2, 3, False)
        self.ppn3_type = scn.SubmanifoldConvolution(self._dimension, nPlanes[0], num_classes, 3, False)
        # Classify track endpoints into start/end points
        if self._classify_endpoints:
            self.ppn3_endpoint = scn.SubmanifoldConvolution(self._dimension, nPlanes[0], 2, 3, False)

        self.add_labels1 = AddLabels()
        self.add_labels2 = AddLabels()

        self.ghost_mask = GhostMask(self._dimension)

        print('Total Number of Trainable Parameters (ppn)= {}'.format(
                    sum(p.numel() for p in self.parameters() if p.requires_grad)))

    def forward(self, input):
        """
        spatial size of feature_map1 (PPN1) = spatial_size / 2**self.ppn1_stride
        spatial size of feature_map2 (PPN2) = spatial_size / 2**self.ppn2_stride
        spatial size of feature_map3 = spatial_size (original)
        """
        label = None if not 'label' in input else input['label'][:, :-1]
        ppn1_feature_enc = input['ppn_feature_enc']
        ppn1_feature_dec = input['ppn_feature_dec']
        assert len(ppn1_feature_enc) == self._num_strides+1
        assert len(ppn1_feature_dec) == self._num_strides
        #print("PPN1/2 stride = ", self.ppn1_stride, self.ppn2_stride)
        if self._use_encoding:
            feature_map1 = ppn1_feature_enc[self.ppn1_stride]
            feature_map2 = ppn1_feature_enc[self.ppn2_stride]
            feature_map3 = ppn1_feature_enc[0]
        else:
            feature_map1 = ppn1_feature_dec[self._num_strides-1-self.ppn1_stride]
            feature_map2 = ppn1_feature_dec[self._num_strides-1-self.ppn2_stride]
            feature_map3 = ppn1_feature_dec[self._num_strides-1]

        # If ghost mask is present, downsample it and use it before conv
        if self._downsample_ghost:
            with torch.no_grad():
                if self._use_true_ghost_mask:
                    # ???
                    ghost_mask = input['segment_label'] < self._num_classes
                else:
                    ghost_mask = 1.0 - torch.argmax(input['ghost'], dim=1)
                coords = ppn1_feature_enc[0].get_spatial_locations()
                # print('Strides = ', self.ppn1_stride, self.ppn2_stride)
                # print('Len(ppn1_feature_dec) = ', len(ppn1_feature_dec), ' Num strides = ', self._num_strides)
                # print('Feature maps = ', feature_map1.features.size(), feature_map2.features.size(), feature_map3.features.size())
                # print(feature_map1.spatial_size)
                # print(feature_map2.spatial_size)
                # print(feature_map3.spatial_size)
                # print(ghost_mask.shape)
                # print(coords.shape)
                feature_map1, ghost_mask1 = self.ghost_mask(ghost_mask, coords, feature_map1, factor=self.ppn1_stride)
                feature_map2, ghost_mask2 = self.ghost_mask(ghost_mask, coords, feature_map2, factor=self.ppn2_stride)
                feature_map3, _ = self.ghost_mask(ghost_mask, coords, feature_map3, factor=0.0)

        # Feature map 1 = deepest
        x = self.ppn1_conv(feature_map1)
        ppn1_scores = self.ppn1_scores(x)
        mask = self.selection1(ppn1_scores)
        attention = self.unpool1(mask)
        if self.training and label is not None:
            with torch.no_grad():
                attention = self.add_labels1(attention, torch.cat([label[:, :-2]/2**self.ppn2_stride, label[:, -2][:, None]], dim=1).long())

        # Feature map 2 = intermediate
        y = self.multiply1(feature_map2, attention)
        y = self.ppn2_conv(y)
        ppn2_scores = self.ppn2_scores(y)
        mask2 = self.selection2(ppn2_scores)
        attention2 = self.unpool2(mask2)
        if self.training and label is not None:
            with torch.no_grad():
                attention2 = self.add_labels2(attention2, label[:,:-1].long())

        # Feature map 3 = original spatial size
        z = self.multiply2(feature_map3, attention2)
        z = self.ppn3_conv(z)
        ppn3_pixel_pred = self.ppn3_pixel_pred(z)
        ppn3_scores = self.ppn3_scores(z)
        ppn3_type = self.ppn3_type(z)
        if self._classify_endpoints:
            ppn3_endpoint = self.ppn3_endpoint(z)

        pixel_pred = ppn3_pixel_pred.features
        scores = ppn3_scores.features
        point_type = ppn3_type.features

        if torch.cuda.is_available():
            result = {'points' : [torch.cat([pixel_pred, scores, point_type], dim=1)],
                      'ppn1'  : [torch.cat([ppn1_scores.get_spatial_locations().cuda().float(), ppn1_scores.features], dim=1)],
                      'ppn2'  : [torch.cat([ppn2_scores.get_spatial_locations().cuda().float(), ppn2_scores.features], dim=1)],
                      'mask_ppn1'  : [attention.features],
                      'mask_ppn2' : [attention2.features]}
        else:
            result = {'points' : [torch.cat([pixel_pred, scores, point_type], dim=1)],
                      'ppn1'  : [torch.cat([ppn1_scores.get_spatial_locations().float(), ppn1_scores.features], dim=1)],
                      'ppn2'  : [torch.cat([ppn2_scores.get_spatial_locations().float(), ppn2_scores.features], dim=1)],
                      'mask_ppn1'  : [attention.features],
                      'mask_ppn2' : [attention2.features]}
        if self._downsample_ghost:
            result['ghost_mask1'] = [ghost_mask1]
            result['ghost_mask2'] = [ghost_mask2]
        if self._classify_endpoints:
            result['classify_endpoints'] = [ppn3_endpoint.features]

        return result


class PPNLoss(torch.nn.modules.loss._Loss):
    """
    Loss for PPN.

    Configuration TO BE COMPLETED
    -------------
    downsample_ghost: bool, optional
        Whether to apply downsampled ghost mask in PPN forward and loss computation.
    weight_ppn1: float, optional
        Weight for PPN1 loss.
    true_distance_ppn1: float, optional
    true_distance_ppn2: float, optional
    true_distance_ppn3: float, optional
    score_threshold: float, optional
    random_sample_negatives: bool, optional
        Whether to compute the PPN1/2/3 losses by randomly sampling negatives, to limit the cases where the true point is very far away from any voxel after deghosting (would lead to penalizing the network unfairly)
    near_sampling: bool, optional
        In addition to above, also sample randomly negatives in the neighborhood of positives.
    sampling_factor: int, optional
        How many samples to draw from negatives (for both `random_sampling_negatives` and `near_sampling` options).
    """
    def __init__(self, cfg, reduction='sum'):
        super(PPNLoss, self).__init__(reduction=reduction)
        self._cfg = cfg['ppn']
        self._dimension = self._cfg.get('data_dim', 3)
        self._num_strides = self._cfg.get('num_strides', 5)
        self._num_classes = self._cfg.get('num_classes', 5)
        self.cross_entropy = torch.nn.CrossEntropyLoss(reduction='none')

        self.half_stride = int((self._num_strides-1)/2.0)
        self.half_stride2 = int(self._num_strides/2.0)
        self._downsample_ghost = self._cfg.get('downsample_ghost', False)
        self._classify_endpoints = self._cfg.get('classify_endpoints', False)
        self._weight_ppn1 = self._cfg.get('weight_ppn1', 1.0)
        self._weight_distance = self._cfg.get('weight_distance', 1.0)

        self._weight_ppn = self._cfg.get('weight_ppn', -1)
        self._use_weight_ppn = True
        if self._weight_ppn == -1:
            self._weight_ppn = 0.5
            self._use_weight_ppn = False

        self._true_distance_ppn1 = self._cfg.get('true_distance_ppn1', 1.0)
        self._true_distance_ppn2 = self._cfg.get('true_distance_ppn2', 1.0)
        self._true_distance_ppn3 = self._cfg.get('true_distance_ppn3', 5.0)
        self._score_threshold = self._cfg.get('score_threshold', 0.5)
        self._random_sample_negatives = self._cfg.get('random_sample_negatives', False)
        self._near_sampling = self._cfg.get('near_sampling', False)
        self._sampling_factor = self._cfg.get('sampling_factor', 20)

        self._ppn1_size = self._cfg.get('ppn1_size', -1)
        self._ppn2_size = self._cfg.get('ppn2_size', -1)
        self._spatial_size = self._cfg.get('spatial_size', 512)
        self._track_label = self._cfg.get('track_label', 1)

        self.ppn1_stride, self.ppn2_stride = define_ppn12(self._ppn1_size, self._ppn2_size, self._spatial_size, self._num_strides)

    def forward(self, result, segment_label, particles):
        """
        result[0], segment_label and weight are lists of size #gpus = batch_size.
        result has only 1 element because UResNet returns only 1 element.
        segment_label[0] has shape (N, 1) where N is #pts across minibatch_size events.
        weight can be None.
        """
        assert len(result['points']) == len(particles)
        assert len(result['points']) == len(segment_label)
        batch_ids = [d[:, -2] for d in segment_label]
        total_loss = 0.
        total_acc = 0.
        ppn_count, ppn_track_count = 0., 0.
        total_distance, total_class = 0., 0.
        total_loss_ppn1, total_loss_ppn2 = 0., 0.
        total_acc_ppn1, total_acc_ppn2 = 0., 0.
        total_fraction_positives_ppn1, total_fraction_negatives_ppn1 = 0., 0.
        total_fraction_positives_ppn2, total_fraction_negatives_ppn2 = 0., 0.
        total_acc_type, total_loss_type = 0., 0.
        total_acc_classify_endpoints, total_loss_classify_endpoints = 0., 0.
        num_labels = 0.
        num_discarded_labels_ppn1, num_discarded_labels_ppn2 = 0., 0.
        total_num_positives_ppn1, total_num_positives_ppn2 = 0., 0.
        data_dim = self._dimension
        for i in range(len(segment_label)):
            event_particles = particles[i]
            for b in batch_ids[i].unique():
                batch_index = batch_ids[i] == b
                event_data = segment_label[i][batch_index][:, :data_dim]  # (N, 3)
                ppn1_batch_index = result['ppn1'][i][:, -3] == b.float()
                ppn2_batch_index = result['ppn2'][i][:, -3] == b.float()
                event_ppn1_data = result['ppn1'][i][ppn1_batch_index][:, :-3]  # (N1, 3)
                event_ppn2_data = result['ppn2'][i][ppn2_batch_index][:, :-3]  # (N2, 3)
                anchors = (event_data + 0.5).float()

                event_pixel_pred = result['points'][i][batch_index][:, :data_dim] + anchors # (N, 3)
                event_scores = result['points'][i][batch_index][:, data_dim:(data_dim+2)]  # (N, 2)
                event_types = result['points'][i][batch_index][:, (data_dim+2):]  # (N, num_classes)
                event_ppn1_scores = result['ppn1'][i][ppn1_batch_index][:, -2:]  # (N1, 2)
                event_ppn2_scores = result['ppn2'][i][ppn2_batch_index][:, -2:]  # (N2, 2)

                # PPN stuff
                event_label = event_particles[event_particles[:, -4] == b][:, :-4]  # (N_gt, 3)
                event_types_label = event_particles[event_particles[:, -4] == b][:, -3]
                if event_label.size(0) > 0:
                    # Mask: only consider pixels that were selected
                    event_mask = result['mask_ppn2'][i][batch_index]
                    event_mask = (~(event_mask == 0)).any(dim=1)  # (N,)

                    if event_mask.int().sum() == 0:
                        print('event_mask before downsample = 0')
                        continue

                    if self._downsample_ghost:
                        event_ghost = 1.0-torch.argmax(result['ghost'][i][batch_index], dim=1)
                        # event_ghost = segment_label[i][batch_index][:, -1] < self._num_classes
                        # print('event_ghost', (event_ghost>0).sum(), event_ghost.size(), (event_mask>0).sum(), event_mask.size())
                        event_mask = event_mask & (event_ghost == 1)

                    if event_mask.int().sum() == 0:
                        print('i = %d, batch id = %d, event_mask after downsample = 0' % (i, b))
                        continue

                    event_pixel_pred = event_pixel_pred[event_mask]
                    event_scores = event_scores[event_mask]
                    event_types = event_types[event_mask]
                    event_data = event_data[event_mask]

                    # Mask for PPN2 (intermediate)
                    # We mask by ghost predictions + ppn1 predictions
                    event_ppn2_mask = (~(result['mask_ppn1'][i][ppn2_batch_index] == 0)).any(dim=1)
                    # event_ppn2_mask = torch.nn.functional.softmax(result['ppn2'][i][ppn2_batch_index][:, 4:], dim=1)[:, 1] > self._score_threshold
                    if self._downsample_ghost:
                        event_ppn2_mask = event_ppn2_mask & (result['ghost_mask2'][i][ppn2_batch_index] == 1).reshape((-1,))
                        # l = segment_label[i][batch_index]
                        # coords = torch.floor(l[:, :3] / float(2**self.half_stride) ).cpu().detach().numpy()
                        # _, indices = np.unique(coords, axis=0, return_index=True)
                        # l = torch.cat([torch.floor(l[indices][:, :3]/float(2**self.half_stride)), l[indices][:, 3:]], dim=1)

                        # coords = event_ppn2_data.cpu().detach().numpy()
                        # perm = np.lexsort((coords[:, 2], coords[:, 1], coords[:, 0]))
                        # inv_perm = np.argsort(perm)
                        # event_ppn2_mask = event_ppn2_mask & (l[inv_perm][:, -1] < self._num_classes)
                    if event_ppn2_mask.int().sum() == 0:
                        print('event_ppn2_mask = 0')
                        continue
                    event_ppn2_data = event_ppn2_data[event_ppn2_mask]
                    event_ppn2_scores = event_ppn2_scores[event_ppn2_mask]

                    # Mask for PPN1 (coarsest)
                    # predicted ghost mask applied at this spatial size
                    # event_mask_ppn1 = torch.nn.functional.softmax(result['ppn1'][i][ppn1_batch_index][:, 4:], dim=1)[:, 1] > self._score_threshold
                    if self._downsample_ghost:
                        event_mask_ppn1 = (result['ghost_mask1'][i][ppn1_batch_index] == 1).reshape((-1,))
                        event_ppn1_data = event_ppn1_data[event_mask_ppn1]
                        event_ppn1_scores = event_ppn1_scores[event_mask_ppn1]
                        if event_mask_ppn1.int().sum() == 0:
                            print('event_mask_ppn1 = 0')
                            continue

                    # Segmentation loss (predict positives)
                    d = distances(event_label, event_pixel_pred)
                    d_true = distances(event_label, event_data)
                    positives = (d_true < self._true_distance_ppn3).any(dim=0)  # FIXME can be empty
                    num_positives = positives.long().sum()
                    weight_ppn = torch.tensor([1-self._weight_ppn, self._weight_ppn]).double()
                    if torch.cuda.is_available():
                        weight_ppn = weight_ppn.cuda()
                    # if num_positives == 0:
                    #     print('num positives = 0')
                    #     continue
                    if self._random_sample_negatives:
                        neg_sample_index = torch.randperm(positives.nelement() - num_positives)[:self._sampling_factor*max(num_positives, 1)]
                        neg_index = torch.nonzero(1-positives.long())[neg_sample_index]

                        index = (positives == 1)
                        index[neg_index] = True

                        if self._near_sampling:
                            near_positives = (d_true < self._true_distance_ppn3*2).any(dim=0) & (~positives)
                            near_sample_index = torch.randperm(near_positives.long().sum())[:self._sampling_factor*max(num_positives, 1)]
                            near_index = torch.nonzero(near_positives.long())[near_sample_index]
                            index[near_index] = True
                        weight = torch.Tensor([1.0, self._sampling_factor*(2 if self._near_sampling else 1)]).double()
                        if torch.cuda.is_available():
                            weight = weight.cuda()
                        loss_seg = torch.nn.functional.cross_entropy(event_scores[index].double(), positives[index].long(), weight=weight)
                    else:
                        num_positives = positives.long().sum()
                        num_negatives = positives.nelement() - num_positives
                        w = num_positives.float() / (num_positives + num_negatives).float()
                        weight_ppn3 = torch.stack([w, 1-w]).double()
                        #print("ppn3", weight_ppn3)
                        #weight_ppn3 = torch.tensor([0.1, 0.9]).double()
                        # loss_seg = torch.mean(self.cross_entropy(event_scores.double(), positives.long()))
                        # loss_seg = torch.nn.functional.cross_entropy(event_scores.double(), positives.long(), weight=weight_ppn3)
                        loss_seg = torch.nn.functional.cross_entropy(event_scores.double(), positives.long(), weight=weight_ppn if self._use_weight_ppn else weight_ppn3)
                    total_class += loss_seg

                    # Accuracy for scores
                    predicted_labels = torch.argmax(event_scores, dim=-1)
                    acc = (predicted_labels == positives.long()).sum().item() / float(predicted_labels.nelement())

                    # Loss ppn1 & ppn2 (predict positives)
                    # print(event_label.size())
                    event_label_ppn1 = torch.floor(event_label/float(2**self.ppn1_stride))
                    event_label_ppn2 = torch.floor(event_label/float(2**self.ppn2_stride))
                    d_true_ppn1 = distances(event_label_ppn1, event_ppn1_data)
                    d_true_ppn2 = distances(event_label_ppn2, event_ppn2_data)
                    positives_ppn1 = (d_true_ppn1 < self._true_distance_ppn1).any(dim=0)
                    positives_ppn2 = (d_true_ppn2 < self._true_distance_ppn2).any(dim=0)

                    num_positives_ppn1 = positives_ppn1.long().sum()
                    num_negatives_ppn1 = positives_ppn1.nelement() - num_positives_ppn1
                    w = num_positives_ppn1.float() / (num_positives_ppn1 + num_negatives_ppn1).float()
                    weight_ppn1 = torch.stack([w, 1-w]).double() if not self._use_weight_ppn else weight_ppn
                    # print("ppn1", weight_ppn1)
                    # weight_ppn1 = weight_ppn

                    num_positives_ppn2 = positives_ppn2.long().sum()
                    num_negatives_ppn2 = positives_ppn2.nelement() - num_positives_ppn2
                    w2 = num_positives_ppn2.float() / (num_positives_ppn2 + num_negatives_ppn2).float()
                    weight_ppn2 = torch.stack([w2, 1-w2]).double() if not self._use_weight_ppn else weight_ppn
                    # print("ppn2", weight_ppn2)
                    # weight_ppn2 = weight_ppn
                    # print('num positives ppn1', num_positives_ppn1)
                    # print((~(d_true_ppn1 < self._true_distance).any(dim=1)).sum())
                    # print((~(d_true_ppn2 < self._true_distance).any(dim=1)).sum())
                    # print(event_label_ppn1[~(d_true_ppn1 < self._true_distance).any(dim=1)]*16.0)
                    # print(d_true_ppn1[~(d_true_ppn1 < self._true_distance).any(dim=1)].min(dim=1))
                    # print(event_ppn1_data[positives_ppn1.byte()]*16.0)
                    num_labels += event_label.size(0)
                    num_discarded_labels_ppn1 += (~(d_true_ppn1 < self._true_distance_ppn1).any(dim=1)).sum().item()
                    num_discarded_labels_ppn2 += (~(d_true_ppn2 < self._true_distance_ppn2).any(dim=1)).sum().item()

                    if self._random_sample_negatives:
                        neg_sample_index = torch.randperm(num_negatives_ppn1)[:self._sampling_factor*max(num_positives_ppn1, 1)]
                        neg_index = torch.nonzero(1-positives_ppn1.long())[neg_sample_index]

                        index = (positives_ppn1 == 1)
                        index[neg_index] = True

                        if self._near_sampling:
                            near_positives_ppn1 = (d_true_ppn1 < self._true_distance_ppn1*2).any(dim=0) & (~positives_ppn1)
                            near_sample_index = torch.randperm(near_positives_ppn1.long().sum())[:20*max(num_positives_ppn1, 1)]
                            near_index = torch.nonzero(near_positives_ppn1.long())[near_sample_index]
                            index[near_index] = True
                        loss_seg_ppn1 = torch.nn.functional.cross_entropy(event_ppn1_scores[index].double(), positives_ppn1[index].long(), weight=weight)

                        neg_sample_index2 = torch.randperm(num_negatives_ppn2)[:20*max(num_positives_ppn2, 1)]
                        neg_index = torch.nonzero(1-positives_ppn2.long())[neg_sample_index2]

                        index = (positives_ppn2 == 1)
                        index[neg_index] = True

                        if self._near_sampling:
                            near_positives_ppn2 = (d_true_ppn2 < self._true_distance_ppn2*2).any(dim=0) & (~positives_ppn2)
                            near_sample_index2 = torch.randperm(near_positives_ppn2.long().sum())[:self._sampling_factor*max(num_positives_ppn2, 1)]
                            near_index = torch.nonzero(near_positives_ppn2.long())[near_sample_index2]
                            index[near_index] = True
                        loss_seg_ppn2 = torch.nn.functional.cross_entropy(event_ppn2_scores[index].double(), positives_ppn2[index].long(), weight=weight)
                    else:
                        # loss_seg_ppn1 = torch.mean(self.cross_entropy(event_ppn1_scores.double(), positives_ppn1))
                        loss_seg_ppn1 = torch.nn.functional.cross_entropy(event_ppn1_scores.double(), positives_ppn1.long(), weight=weight_ppn1)
                        # loss_seg_ppn2 = torch.mean(self.cross_entropy(event_ppn2_scores.double(), positives_ppn2))
                        loss_seg_ppn2 = torch.nn.functional.cross_entropy(event_ppn2_scores.double(), positives_ppn2.long(), weight=weight_ppn2)
                    predicted_labels_ppn1 = torch.argmax(event_ppn1_scores, dim=-1)
                    predicted_labels_ppn2 = torch.argmax(event_ppn2_scores, dim=-1)
                    acc_ppn1 = (predicted_labels_ppn1 == positives_ppn1.long()).sum().item() / float(predicted_labels_ppn1.nelement())
                    acc_ppn2 = (predicted_labels_ppn2 == positives_ppn2.long()).sum().item() / float(predicted_labels_ppn2.nelement())
                    if predicted_labels_ppn1[positives_ppn1 > 0].nelement() > 0:
                        fraction_positives_ppn1 = (predicted_labels_ppn1[positives_ppn1 > 0] == positives_ppn1[positives_ppn1 > 0].long()).sum().item() / float(predicted_labels_ppn1[positives_ppn1 > 0].nelement())
                        total_fraction_positives_ppn1 += fraction_positives_ppn1
                    if predicted_labels_ppn1[positives_ppn1 == 0].nelement() > 0:
                        fraction_negatives_ppn1 = (predicted_labels_ppn1[positives_ppn1 == 0] == positives_ppn1[positives_ppn1 == 0].long()).sum().item() / float(predicted_labels_ppn1[positives_ppn1 == 0].nelement())
                        total_fraction_negatives_ppn1 += fraction_negatives_ppn1
                    if predicted_labels_ppn2[positives_ppn2 > 0].nelement() > 0:
                        fraction_positives_ppn2 = (predicted_labels_ppn2[positives_ppn2 > 0] == positives_ppn2[positives_ppn2 > 0].long()).sum().item() / float(predicted_labels_ppn2[positives_ppn2 > 0].nelement())
                        total_fraction_positives_ppn2 += fraction_positives_ppn2
                    if predicted_labels_ppn2[positives_ppn2 == 0].nelement() > 0:
                        fraction_negatives_ppn2 = (predicted_labels_ppn2[positives_ppn2 == 0] == positives_ppn2[positives_ppn2 == 0].long()).sum().item() / float(predicted_labels_ppn2[positives_ppn2 == 0].nelement())
                        total_fraction_negatives_ppn2 += fraction_negatives_ppn2
                    #print(num_positives_ppn1, num_negatives_ppn1, w, acc_ppn1)
                    total_num_positives_ppn1 += num_positives_ppn1
                    total_num_positives_ppn2 += num_positives_ppn2
                    # Distance loss
                    # positives = (d_true[:, event_mask] < 5).any(dim=0)
                    # distances_positives = d[:, event_mask][:, positives]
                    distances_positives = d[:, positives]
                    if distances_positives.shape[1] > 0:
                        d2, _ = torch.min(distances_positives, dim=0)
                        loss_seg += d2.mean()
                        total_distance += d2.mean()

                        # Loss for point type
                        labels = event_types_label[torch.argmin(distances_positives, dim=0)]
                        loss_type = torch.mean(self.cross_entropy(event_types[positives].double(), labels.long()))

                        # Accuracy for point type
                        predicted_types = torch.argmax(event_types[positives], dim=-1)
                        acc_type = (predicted_types == labels.long()).sum().item() / float(predicted_types.nelement())

                        total_acc_type += acc_type
                        total_loss_type += loss_type
                        total_loss += loss_type.float()

                    if self._classify_endpoints:
                        if distances_positives.size(0) > 0 and distances_positives.size(1) > 0:
                            tracks = event_types_label[torch.argmin(distances_positives, dim=0)] == self._track_label
                            if tracks.sum().item() > 0:
                                # Start and end points separately in case of overlap
                                loss_point_class, acc_point_class, point_class_count = 0., 0., 0.
                                for point_class in range(2):
                                    point_class_mask = event_particles[event_particles[:, -4] == b][:, -1] == point_class
                                    #true = event_particles[event_particles[:, -4] == b][torch.argmin(distances_positives, dim=0), -1]
                                    point_class_positives = (d_true[point_class_mask, :] < self._true_distance_ppn3).any(dim=0)
                                    point_class_index = d[point_class_mask, :][:, point_class_positives]

                                    if point_class_index.nelement():
                                        point_class_index = torch.argmin(point_class_index, dim=0)

                                        true = event_particles[event_particles[:, -4] == b][point_class_mask][point_class_index, -1]
                                        #pred = result['classify_endpoints'][i][batch_index][event_mask][positives]
                                        pred = result['classify_endpoints'][i][batch_index][event_mask][point_class_positives]
                                        tracks = event_types_label[point_class_index] == self._track_label
                                        if tracks.sum().item():
                                            loss_point_class += torch.mean(self.cross_entropy(pred[tracks].double(), true[tracks].long()))
                                            acc_point_class += (torch.argmax(pred[tracks], dim=-1) == true[tracks]).sum().item() / float(true[tracks].nelement())
                                            point_class_count += 1

                                if point_class_count:
                                    loss_classify_endpoints = loss_point_class / point_class_count
                                    acc_classify_endpoints = acc_point_class / point_class_count
                                    #total_loss += loss_classify_endpoints.float()
                                    total_loss_classify_endpoints += loss_classify_endpoints
                                    total_acc_classify_endpoints += acc_classify_endpoints
                                    ppn_track_count += 1

                    total_loss_ppn1 += loss_seg_ppn1
                    total_loss_ppn2 += loss_seg_ppn2
                    total_acc_ppn1 += acc_ppn1
                    total_acc_ppn2 += acc_ppn2
                    total_loss += (self._weight_distance*loss_seg + self._weight_ppn1*loss_seg_ppn1 + loss_seg_ppn2).float()
                    total_acc += acc
                    ppn_count += 1
                else:
                    print("No particles !")

        ppn_results = {
            'ppn_acc': total_acc,
            'ppn_loss': total_loss,
            'loss_class': total_class,
            'loss_distance': total_distance,
            'loss_ppn1': total_loss_ppn1,
            'loss_ppn2': total_loss_ppn2,
            'acc_ppn1': total_acc_ppn1,
            'acc_ppn2': total_acc_ppn2,
            'fraction_positives_ppn1': total_fraction_positives_ppn1,
            'fraction_positives_ppn2': total_fraction_positives_ppn2,
            'fraction_negatives_ppn1': total_fraction_negatives_ppn1,
            'fraction_negatives_ppn2': total_fraction_negatives_ppn2,
            'acc_ppn_type': total_acc_type,
            'loss_type': total_loss_type,
            'acc_ppn_classify_endpoints': total_acc_classify_endpoints,
            'loss_classify_endpoints': total_loss_classify_endpoints,
            'num_labels': num_labels,
            'num_discarded_labels_ppn1': num_discarded_labels_ppn1,
            'num_discarded_labels_ppn2': num_discarded_labels_ppn2,
            'num_positives_ppn1': total_num_positives_ppn1,
            'num_positives_ppn2': total_num_positives_ppn2
        }
        for key in ppn_results:
            if not isinstance(ppn_results[key], torch.Tensor):
                ppn_results[key] = torch.tensor(ppn_results[key])
                if torch.cuda.is_available():
                    ppn_results[key] = ppn_results[key].cuda()
        if ppn_count > 0:
            for key in ppn_results:
                if 'classify_endpoints' in key:
                    ppn_results[key] = ppn_results[key] / float(ppn_track_count)
                else:
                    ppn_results[key] = ppn_results[key] / float(ppn_count)
            ppn_results['ppn_loss'] += ppn_results['loss_classify_endpoints']

        return ppn_results
